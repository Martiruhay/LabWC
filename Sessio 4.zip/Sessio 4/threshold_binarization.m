function [ output_image ] = threshold_binarization( input_image, input_area )
%UNTITLED3 Summary of this function goes here
%   blister 31200

h = imhist(input_image);
lambda = 0;
for i=1:256
   if sum(h(i:256)) < input_area
       lambda = i - 1; 
       break;
   end
end

output_image = input_image > lambda;
end

