%% L4 - Binaritzaci�
%% Imatge BW
I = imread('money.tif');
h = imhist(I);
plot(h);
BW1 = I < 50;
BW2 = I > 120;

%% Imatge RGB (metode 1)
I = imread('Enters manuscrits 1.jpg');
hsv = rgb2hsv(I);
h = 270/360 > hsv(:,:,1) > 180/360;
s = 100/100 > hsv(:,:,2) > 10/100;
v = 46/100 > hsv(:,:,3) > 15/100;
final = h & s & v;
imshow(final);

%% Imatge RGB (metode 2)
I = imread('Enters manuscrits 1.jpg');
hsv = rgb2hsv(I);
h = hsv(:,:,1);
s = hsv(:,:,2);
v = hsv(:,:,3);
d = (230/360 - h).^2 + (50/100 - s).^2 + (22/100 - v).^2;
final = d < 0.25;
imshow(final);

%% Gradients amb Sobel
I = imread('coins.png');
bws = edge(I,'Sobel');
imshow(bws);

%% Gradients amb Canny
I = imread('coins.png');
bws = edge(I,'Canny');
imshow(bws);

%% Gradients mitjan�ant Suavitzant (Gaussian)
I = imread('coins.png');
h = fspecial('Gaussian', 5);
If = imfilter(I,h);
imshowpair(I,I-If,'montage');

%% Gradients mitjan�ant Suavitzant (Average)
I = imread('coins.png');
h = fspecial('Average', 5);
If = imfilter(I,h);
imshowpair(I,(I-If)>8,'montage');

