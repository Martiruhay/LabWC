function [ output_args ] = window_binarization( input_image, N, M )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
output_args = colfilt(input_image, [N M], 'sliding', @my_winbin_function);

end

