function [ o ] = my_winbin_function( i )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
K = 4;
[N,M] = size(i);

x = floor(N/2) + 1;

mitja = cast(floor(mean(i)), 'uint8') + K;

o = i(x,:) < mitja;

end

