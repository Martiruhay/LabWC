function [ output_image ] = alpha_binarization( input_image, input_alpha )

lmax = max(max(input_image));
lmin = min(min(input_image));

lambda = input_alpha*(lmax - lmin) + lmin;

output_image = input_image > lambda;
end

